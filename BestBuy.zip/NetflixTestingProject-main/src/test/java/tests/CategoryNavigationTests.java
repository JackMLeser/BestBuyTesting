package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.util.List;

import static org.testng.Assert.*;

public class CategoryNavigationTests extends BaseTest {

    @Test
    public void navigateToTVsAndHomeTheater() {
        WebElement menuLink = driver.findElement(By.linkText("TVs & Home Theater"));
        menuLink.click();

        String currentUrl = driver.getCurrentUrl();
        assertTrue(currentUrl.contains("tv-home-theater"), "Failed to navigate to TVs & Home Theater");
    }

    @Test
    public void click4KTVsSubcategory() {
        WebElement subcategoryLink = driver.findElement(By.linkText("4K Ultra HD TVs"));
        subcategoryLink.click();

        String pageTitle = driver.getTitle();
        assertTrue(pageTitle.contains("4K Ultra HD"), "Subcategory title does not match expected");
    }

    @Test
    public void verifyCategoryBanner() {
        WebElement banner = driver.findElement(By.cssSelector("h1.heading-5"));
        String bannerText = banner.getText();
        assertTrue(bannerText.contains("4K"), "Banner does not mention 4K");
    }

    @Test
    public void countItemsDisplayed() {
        List<WebElement> productItems = driver.findElements(By.cssSelector(".sku-item"));
        int count = productItems.size();
        System.out.println("Total product items displayed: " + count);
        assertTrue(count > 0, "No product items found");
    }

    @Test
    public void validateBreadcrumbTrail() {
        List<WebElement> breadcrumbs = driver.findElements(By.cssSelector(".breadcrumb li"));
        boolean found = breadcrumbs.stream().anyMatch(b -> b.getText().contains("4K Ultra HD TVs"));
        assertTrue(found, "Breadcrumb trail does not contain '4K Ultra HD TVs'");
    }
}
