package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

public class SearchPageTests extends BaseTest {

    @Test
    public void searchForLaptops() {
        driver.get("https://www.bestbuy.com");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-search-input"))).sendKeys("laptop");

        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[aria-label='submit search']"))).click();

        wait.until(ExpectedConditions.urlContains("searchpage.jsp"));

        assert driver.getTitle().toLowerCase().contains("laptop");
    }


    @Test
    public void filterCellPhonesByIphoneCategory() {
        driver.get("https://www.bestbuy.com");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-search-input")));
        searchBox.sendKeys("cell phone");

        WebElement searchBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[aria-label='submit search']")));
        searchBtn.click();

        WebElement iphoneFilterButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[data-id='pcmcat305200050000']")));
        iphoneFilterButton.click();

        wait.until(ExpectedConditions.urlContains("qp=category_facet%3DiPhone"));
        String currentUrl = driver.getCurrentUrl();
        assert currentUrl.contains("category_facet%3DiPhone") : "iPhone filter not applied in URL!";
    }

    @Test
    public void filterCoffeeMachinesByBrevilleBrand() {
        driver.get("https://www.bestbuy.com");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-search-input")));
        searchBox.sendKeys("coffee machine");

        WebElement searchBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[aria-label='submit search']")));
        searchBtn.click();

        WebElement brevilleCheckbox = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("input[id='Breville']")));
        brevilleCheckbox.click();

        WebElement brevilleFilterBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("button.quick-filter-item.selected[aria-label='Breville']")));

        assert brevilleFilterBtn.isDisplayed() : "Breville filter not selected as expected.";

        try {
            Thread.sleep(4000); // 4 seconds
        } catch (InterruptedException e) {
            e.printStackTrace(); // or just log it
        }

    }

    @Test
    public void searchAndVerifyBrevilleBambinoProduct() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        driver.get("https://www.bestbuy.com");
        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-search-input")));
        searchBox.sendKeys("Breville - Bambino - Brushed Stainless Steel");

        WebElement searchBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[aria-label='submit search']")));
        searchBtn.click();

        List<WebElement> items = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
                By.cssSelector("li[data-testid='6494620'] a.product-list-item-link")));

        if (!items.isEmpty()) {
            items.get(0).click();  // click the first one
        } else {
            throw new RuntimeException("Breville Bambino product not found");
        }



        wait.until(ExpectedConditions.urlContains("6494620"));

        WebElement featuresTab = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(@class, 'features-drawer-btn')]//span[text()='Features']")));
        featuresTab.click();

        WebElement productName = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@class='sku-title']/h1[contains(text(),'Breville - Bambino - Brushed')]")));
        assert productName.isDisplayed();

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void searchWithSortingAndVerifySortUrlOnly() {
        driver.get("https://www.bestbuy.com");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-search-input")));
        searchBox.sendKeys("laptop");

        WebElement searchBtn = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[aria-label='submit search']")));
        searchBtn.click();

        WebElement sortDropdown = wait.until(
                ExpectedConditions.elementToBeClickable(By.cssSelector("#sort-by div[role='button']"))
        );
        sortDropdown.click();

        WebElement priceLowToHigh = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//li[@role='menuitemcheckbox' and @data-testid='-item-3']")
        ));
        priceLowToHigh.click();

        wait.until(ExpectedConditions.urlContains("sp=Price-Low-To-High"));
    }



}
