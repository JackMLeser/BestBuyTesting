package Selenium_Java_Basics;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class ProductsPageTest {
    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\pinto\\Drivers_New\\chromedriver.exe");
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        driver.manage().window().maximize();
        driver.get("https://www.bestbuy.com/");
    }

    @Test(priority = 1)
    public void clickProductFromSearch() {
        // Accept location if prompted
        try {
            WebElement closeLocationPopup = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".c-close-icon.c-modal-close-icon")));
            closeLocationPopup.click();
        } catch (Exception ignored) {}

        // Search for a product
        WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.id("gh-search-input")));
        searchBox.sendKeys("laptop");
        searchBox.sendKeys(Keys.ENTER);

        // Click on the first product
        WebElement firstProduct = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".sku-item .sku-title h4 a")));
        firstProduct.click();
    }

    @Test(priority = 2)
    public void verifyImageGalleryLoads() {
        clickProductFromSearch();
        WebElement imageGallery = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".primary-image")));
        Assert.assertTrue(imageGallery.isDisplayed(), "Image gallery is not displayed");
    }

    @Test(priority = 3)
    public void checkProductTitleAndPrice() {
        clickProductFromSearch();
        WebElement title = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".sku-title h1")));
        WebElement price = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".priceView-hero-price.priceView-customer-price span")));
        Assert.assertFalse(title.getText().isEmpty(), "Product title is empty");
        Assert.assertTrue(price.getText().matches(".*\\$\\d+.*"), "Price format not detected");
    }

    @Test(priority = 4)
    public void validateDescriptionAndSpecs() {
        clickProductFromSearch();
        WebElement descriptionTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Overview')]")));
        descriptionTab.click();
        WebElement specsTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Specifications')]")));
        specsTab.click();
        WebElement specsSection = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".specifications-section")));
        Assert.assertTrue(specsSection.isDisplayed(), "Specifications section not visible");
    }

    @Test(priority = 5)
    public void verifyAddToCartButton() {
        clickProductFromSearch();
        WebElement addToCart = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".add-to-cart-button")));
        Assert.assertTrue(addToCart.isDisplayed(), "Add to Cart button not found");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
