package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

import java.time.Duration;

import static org.testng.Assert.*;

public class HomePageTests extends BaseTest {

    @Test
    public void testHomepageLoadsCorrectly() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.titleContains("Best Buy"));
        assertTrue(driver.getTitle().contains("Best Buy"), "Homepage title does not contain 'Best Buy'.");
    }

    @Test
    public void testNavigationMenuItems() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement menuButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("button[aria-label='Menu']")
        ));
        assertTrue(menuButton.isDisplayed(), "Navigation menu is not visible.");
    }

    @Test
    public void testSearchBarVisibility() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement searchBar = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.id("gh-search-input")
        ));
        assertTrue(searchBar.isDisplayed(), "Search bar is not visible.");
    }

    @Test
    public void testCartIconIsVisible() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        // Close the region modal if present
        try {
            WebElement closeModal = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.cssSelector("button.c-close-icon.c-modal-close-icon")
            ));
            closeModal.click();
        } catch (TimeoutException ignored) {
            System.out.println("Region modal not present.");
        }

        // Wait for the SVG cart icon to be visible
        WebElement cartIcon = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("svg[aria-label='Cart Icon']")
        ));

        assertTrue(cartIcon.isDisplayed(), "Cart icon SVG is not visible.");
    }


    @Test
    public void testFooterLinksVisibleOnScroll() {
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement footer = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.tagName("footer")
        ));
        assertTrue(footer.isDisplayed(), "Footer is not visible after scrolling.");
    }
}
