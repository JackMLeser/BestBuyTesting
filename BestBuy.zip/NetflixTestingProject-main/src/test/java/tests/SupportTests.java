package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;

public class SupportTests {
    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void handleRegionModalIfPresent(WebDriver driver) {
        try {
            WebElement closeBtn = new WebDriverWait(driver, Duration.ofSeconds(5))
                    .until(ExpectedConditions.elementToBeClickable(By.cssSelector(".c-close-icon.c-modal-close-icon")));
            closeBtn.click();
        } catch (TimeoutException ignored) {
            // Modal not present or already closed
        }
    }

    public void scrollIntoView(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    @Test
    public void testCustomerServiceLink() {
        driver.get("https://www.bestbuy.com/support");
        handleRegionModalIfPresent(driver);

        boolean linkExists = driver.getPageSource().contains("Customer Service");
        assert linkExists : "Customer Service text not found on page";
    }

    @Test
    public void testSearchBarIsVisible() {
        driver.get("https://www.bestbuy.com/support");
        handleRegionModalIfPresent(driver);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("input[placeholder*='Search']")));
    }

    @Test
    public void testFaqLinkPresence() {
        driver.get("https://www.bestbuy.com/support");
        handleRegionModalIfPresent(driver);

        boolean faqExists = driver.getPageSource().toLowerCase().contains("faq");
        assert faqExists : "FAQ text not found on page";
    }

    @Test
    public void testBackNavigationRestoresSearchBar() {
        driver.get("https://www.bestbuy.com/support");
        handleRegionModalIfPresent(driver);

        driver.navigate().to("https://www.bestbuy.com/site/help-topics/my-best-buy-memberships-faqs/pcmcat1630361388557.c?id=pcmcat1630361388557");
        driver.navigate().back();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("input[placeholder*='Search']")));
    }

    @Test
    public void testSupportPageTitleContainsSupport() {
        driver.get("https://www.bestbuy.com/support");
        handleRegionModalIfPresent(driver);

        String title = driver.getTitle().toLowerCase();
        assert title.contains("support") : "Page title does not contain 'support'";
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}