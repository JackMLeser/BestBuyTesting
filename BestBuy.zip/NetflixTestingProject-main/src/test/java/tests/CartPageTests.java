package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

public class CartPageTests extends BaseTest {

    @Test
    public void addItemToCartAndVerify() {
        driver.get("https://www.bestbuy.com");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-search-input")));
        searchBox.sendKeys("laptop");

        hideConfirmItBackdropIfPresent();
        WebElement searchBtn = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[aria-label='submit search']")));
        searchBtn.click();

        hideConfirmItBackdropIfPresent();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[data-test-id='add-to-cart'], .add-to-cart-button"))).click();

        hideConfirmItBackdropIfPresent();
        WebElement cartIcon = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".shop-cart-icon .cart-link")));
        cartIcon.click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".cart-item__remove")));
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void addTwoItemsAndChangeQuantities() {
        driver.get("https://www.bestbuy.com");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement searchBox1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-search-input")));
        searchBox1.sendKeys("mouse");

        hideConfirmItBackdropIfPresent();
        driver.findElement(By.cssSelector("button[aria-label='submit search']")).click();

        hideConfirmItBackdropIfPresent();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[data-test-id='add-to-cart'], .add-to-cart-button"))).click();

        WebElement searchBox2 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-search-input")));
        searchBox2.clear();
        searchBox2.sendKeys("keyboard");

        hideConfirmItBackdropIfPresent();
        driver.findElement(By.cssSelector("button[aria-label='submit search']")).click();

        hideConfirmItBackdropIfPresent();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[data-test-id='add-to-cart'], .add-to-cart-button"))).click();

        hideConfirmItBackdropIfPresent();
        WebElement cartIcon = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".shop-cart-icon .cart-link")));
        cartIcon.click();

        List<WebElement> quantityDropdowns = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("select[id^='quantity-']")));
        if (quantityDropdowns.size() >= 2) {
            new Select(quantityDropdowns.get(0)).selectByValue("2");
            new Select(quantityDropdowns.get(1)).selectByValue("3");
        }
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void saveItemForLaterAndUndo() {
        driver.get("https://www.bestbuy.com");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-search-input")));
        searchBox.sendKeys("keyboard");

        hideConfirmItBackdropIfPresent();
        driver.findElement(By.cssSelector("button[aria-label='submit search']")).click();

        hideConfirmItBackdropIfPresent();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[data-test-id='add-to-cart'], .add-to-cart-button"))).click();

        hideConfirmItBackdropIfPresent();
        WebElement cartIcon = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".shop-cart-icon .cart-link")));
        cartIcon.click();

        WebElement saveBtn = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[title='Save for Later']")));
        saveBtn.click();

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement undo = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Undo']")));
        undo.click();

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void verifySubtotalIncreasesWithQuantity() {
        driver.get("https://www.bestbuy.com");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-search-input")));
        searchBox.sendKeys("usb drive");

        hideConfirmItBackdropIfPresent();
        driver.findElement(By.cssSelector("button[aria-label='submit search']")).click();

        hideConfirmItBackdropIfPresent();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[data-test-id='add-to-cart'], .add-to-cart-button"))).click();

        hideConfirmItBackdropIfPresent();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".shop-cart-icon .cart-link"))).click();

        WebElement subtotalElemBefore = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@class='price-summary']//tr[th[text()='Subtotal']]/td")));
        double subtotalBefore = Double.parseDouble(subtotalElemBefore.getText().replace("$", "").replace(",", "").trim());

        WebElement quantityDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("select[id^='quantity-']")));
        new Select(quantityDropdown).selectByValue("2");

        try { Thread.sleep(3000); } catch (InterruptedException ignored) {}

        WebElement subtotalElemAfter = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@class='price-summary']//tr[th[text()='Subtotal']]/td")));
        double subtotalAfter = Double.parseDouble(subtotalElemAfter.getText().replace("$", "").replace(",", "").trim());

        Assert.assertTrue(subtotalAfter > subtotalBefore, "Subtotal should increase when quantity is increased");
    }

    @Test
    public void removeItemFromCart() {
        driver.get("https://www.bestbuy.com");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-search-input")));
        searchBox.sendKeys("usb cable");

        hideConfirmItBackdropIfPresent();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[aria-label='submit search']"))).click();

        hideConfirmItBackdropIfPresent();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[data-test-id='add-to-cart'], .add-to-cart-button"))).click();

        hideConfirmItBackdropIfPresent();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".shop-cart-icon .cart-link"))).click();

        WebElement totalBefore = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@class='price-summary']//span[text()='Total']/ancestor::tr/td")));

        WebElement removeBtn = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".cart-item__remove")));
        removeBtn.click();

        WebElement removedMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//span[text()=\"We’ve removed this item from your cart.\"]")));
        Assert.assertTrue(removedMsg.isDisplayed(), "Removal confirmation message not found");

        WebElement totalAfter = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@class='price-summary']//span[text()='Total']/ancestor::tr/td")));
        Assert.assertEquals(totalAfter.getText(), "$0.00", "Expected total after removal to be $0.00");

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
