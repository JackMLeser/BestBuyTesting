package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class AccountsPageTest extends BaseTest {
    private WebDriverWait wait;

    @BeforeMethod
    public void setup() {
        super.setup();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        System.out.println("Test setup completed");
    }

    private void clickAccountButton() {
        WebElement accountBtn = wait.until(ExpectedConditions.elementToBeClickable(
            By.cssSelector("span.v-p-right-xxs.line-clamp")));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", accountBtn);
        try {
            accountBtn.click();
        } catch (ElementClickInterceptedException e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", accountBtn);
        }
    }

    private void goBack() {
        driver.navigate().back();
        wait.until(ExpectedConditions.jsReturnsValue("return document.readyState === 'complete'"));
    }

    private void handleModals() {
        try {
            // Handle survey modal
            WebElement surveyModal = driver.findElement(By.id("survey_window"));
            if (surveyModal.isDisplayed()) {
                WebElement closeButton = surveyModal.findElement(By.cssSelector("[data-track='Close']"));
                closeButton.click();
            }
        } catch (NoSuchElementException e) {
            // Modal not present, continue
        }
    }

    @Test(priority = 1)
    public void testSignInFlow() {
        System.out.println("Starting sign in flow test");
        try {
            clickAccountButton();
            handleModals();
            
            // Click Sign In
            WebElement signInBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("a[data-testid='signInButton']")));
            signInBtn.click();
            
            // Wait for sign in page to load
            wait.until(ExpectedConditions.urlContains("signin"));
            
            goBack();
            System.out.println("Sign in flow test completed");
        } catch (Exception e) {
            System.out.println("Test failed: " + e.getMessage());
            throw e;
        }
    }

    @Test(priority = 2)
    public void testCreateAccountFlow() {
        System.out.println("Starting create account flow test");
        try {
            clickAccountButton();
            handleModals();
            
            // Click Create Account
            WebElement createAccountBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("a[data-testid='signInButton']")));
            createAccountBtn.click();
            
            // Wait for create account page to load
            wait.until(ExpectedConditions.urlContains("signin"));
            
            // Click Create Account button on sign in page
            WebElement createAccountLink = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("a[href*='create-account']")));
            createAccountLink.click();
            
            // Wait for create account form
            wait.until(ExpectedConditions.urlContains("create-account"));
            
            // Fill in first name
            WebElement firstNameInput = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("input[name='firstName']")));
            firstNameInput.sendKeys("Test");
            
            goBack();
            System.out.println("Create account flow test completed");
        } catch (Exception e) {
            System.out.println("Test failed: " + e.getMessage());
            throw e;
        }
    }

    @Test(priority = 3)
    public void testAccountButtonClick() {
        System.out.println("Starting account button click test");
        try {
            clickAccountButton();
            handleModals();
            goBack();
            System.out.println("Account button click test completed");
        } catch (Exception e) {
            System.out.println("Test failed: " + e.getMessage());
            throw e;
        }
    }

    @Test(priority = 4)
    public void testPurchasesFlow() {
        System.out.println("Starting purchases flow test");
        try {
            clickAccountButton();
            handleModals();
            
            // Click Purchases
            WebElement purchasesLink = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("a[href*='purchasehistory/purchases']")));
            purchasesLink.click();
            
            // Wait for purchases page to load
            wait.until(ExpectedConditions.urlContains("purchases"));
            
            goBack();
            System.out.println("Purchases flow test completed");
        } catch (Exception e) {
            System.out.println("Test failed: " + e.getMessage());
            throw e;
        }
    }

    @Test(priority = 5)
    public void testProductsFlow() {
        System.out.println("Starting products flow test");
        try {
            clickAccountButton();
            handleModals();
            
            // Click Products
            WebElement productsLink = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("a[href*='products']")));
            productsLink.click();
            
            // Wait for products page to load
            wait.until(ExpectedConditions.urlContains("products"));
            
            goBack();
            System.out.println("Products flow test completed");
        } catch (Exception e) {
            System.out.println("Test failed: " + e.getMessage());
            throw e;
        }
    }

    @AfterMethod
    public void cleanup() {
        System.out.println("Running test cleanup");
        try {
            driver.manage().deleteAllCookies();
            System.out.println("Cookies cleared");
        } catch (Exception e) {
            System.out.println("Cleanup failed: " + e.getMessage());
        }
    }
}
